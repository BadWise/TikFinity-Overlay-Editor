# 🎯 Overlay TikFinity - Editor Avançado

## 📋 Visão Geral
Sistema profissional de overlay para TikTok LIVE que permite gerenciar múltiplos widgets do TikFinity com controles avançados de personalização.

## ✨ Recursos Principais

### 🎨 Controles Totalmente Customizáveis
- **Transparência/Opacidade**: Ajuste de 0% a 100%
- **Zoom**: De 10% a 300%
- **Rotação**: 0° a 360°
- **Posição**: Controle preciso X/Y em pixels + drag-and-drop profissional
- **Tamanho**: Largura e altura configuráveis + resize estilo Photoshop
- **Resoluções Predefinidas**: Botões rápidos para 720p, 1080p, 1440p e 4K
- **Camadas (Z-Index)**: Organize widgets em múltiplas camadas
- **Bordas**: Espessura, cor, estilo (sólida/tracejada/pontilhada) e arredondamento

### 📐 Guias Visuais de Resolução
- **Área 720p**: Guia azul mostrando dimensões 1280x720
- **Área 4K**: Guia rosa mostrando dimensões 3840x2160
- **Fundo Cinza**: Editor com fundo cinza para melhor contraste
- **Toggle On/Off**: Ative/desative guias conforme necessário

### 🔍 Zoom de Canvas
- **Zoom Ajustável**: De 25% a 200% da visualização
- **Posicionamento Preciso**: Aumente o zoom para ajustar widgets com precisão
- **Reset Rápido**: Botão para retornar a 100% instantaneamente

### 🖱️ Controles Estilo Photoshop
- **Movimentação**: Arraste widgets com o mouse de forma intuitiva
- **Redimensionamento**: 8 handles de resize (N, S, E, W, NE, NW, SE, SW)
- **Handles visuais**: Círculos nos cantos, barras nas laterais
- **Cursores apropriados**: Cada direção mostra o cursor correto
- **Modo Interativo**: Toggle para habilitar cliques dentro dos iframes

### 🔒 Sistema de Travamento
- Trave widgets individuais para evitar movimentação acidental
- Trave todos os widgets de uma vez (Ctrl+L)
- Modo bloqueado impede resize e drag-and-drop

### 💾 Salvamento e Gerenciamento
- **Presets**: Salve e carregue múltiplas configurações
- **Auto-save**: Última configuração é salva automaticamente
- **Exportação JSON**: Backup externo das configurações
- **Importação JSON**: Restaure configurações de arquivos

### ⌨️ Atalhos de Teclado
- **Ctrl + H**: Ocultar/Mostrar todos os controles
- **Ctrl + S**: Salvar preset atual
- **Ctrl + L**: Travar/Destravar todos os widgets
- **Delete**: Deletar widget selecionado

### 🎨 Templates TikFinity
Templates predefinidos para widgets comuns:
- Like Counter (Contador de Likes)
- Follow Alert (Alerta de Seguidores)
- Gift Counter (Contador de Presentes)
- Chat Overlay (Overlay de Chat)
- Top Gifters (Principais Doadores)
- Goal Bar (Barra de Metas)

## 🚀 Como Usar

### 1. Adicionar Widget
1. Clique em "➕ Adicionar Widget"
2. Cole a URL do widget do TikFinity
3. Ajuste posição e tamanho arrastando ou usando controles precisos

### 2. Usar Templates
1. Clique em "🎨 Templates"
2. Escolha um template predefinido
3. Substitua a URL pela URL real do seu widget TikFinity

### 3. Configurar Widget
- Clique no widget para selecioná-lo
- Use o painel de controles que aparece acima
- Ajuste opacidade, zoom, rotação, borda, etc.
- **Mover**: Clique e arraste o widget
- **Redimensionar**: Arraste os handles nas bordas e cantos
- **Interagir com iframe**: Clique no botão "🖱️ Interagir" para habilitar cliques dentro do widget

### 4. Salvar Configuração
- Método 1: **Ctrl + S** ou botão "💾 Salvar Preset"
- Método 2: A configuração é salva automaticamente ao fechar

### 5. Usar no OBS/TikTok LIVE Studio
1. Copie a URL do overlay (exibida no navegador)
2. No OBS: Adicione "Browser Source"
3. No TikTok LIVE Studio: Adicione "Link Source"
4. Cole a URL e configure transparência se necessário

### 6. Gerar Link Externo (Novo!)
Use o botão **🔗 Link Externo** para criar links sem menus de controle:

**Opção 1: Via Preset (Recomendado)**
- Salve um preset primeiro (💾 Salvar Preset)
- Clique em "🔗 Link Externo" > "Usar Preset"
- Escolha o preset e copie o link gerado
- Exemplo: `view.html?preset=MeuOverlay`
- ✅ Atualizações no preset refletem automaticamente no link

**Opção 2: Via Configuração Codificada**
- Clique em "🔗 Link Externo" > "Gerar Link Agora"
- O link contém todas as configurações embutidas
- ⚠️ Versão fixa - mudanças futuras não aparecem automaticamente

**Opção 3: Auto-save**
- Use simplesmente `view.html`
- Carrega automaticamente a última configuração salva
- Ideal para testes rápidos

**Como usar no OBS/TikTok Studio:**
1. Gere o link externo desejado
2. Copie o link completo
3. No OBS: Browser Source > Cole a URL
4. No TikTok Studio: Link Source > Cole a URL
5. Configure dimensões e transparência conforme necessário

### 7. Modo Transmissão
- Pressione **Ctrl + H** para ocultar todos os controles
- Trave os widgets com **Ctrl + L** para evitar movimentação acidental
- Apenas os iframes ficarão visíveis
- Ou use o link externo gerado para uma visualização 100% limpa

## 📁 Estrutura do Projeto

```
/
├── index.html          # Interface principal do overlay (editor)
├── view.html           # Visualização limpa (sem controles)
├── server.py           # Servidor HTTP (porta 5000)
├── replit.md           # Documentação (este arquivo)
└── .gitignore          # Arquivos ignorados pelo Git
```

## 🔧 Configuração Técnica

### Servidor
- **Tecnologia**: Python 3.11 + HTTP Server
- **Porta**: 5000 (obrigatória para Replit)
- **Host**: 0.0.0.0 (permite acesso externo)
- **Cache**: Desabilitado para desenvolvimento
- **CORS**: Habilitado para uso em iframes

### Armazenamento
- **LocalStorage**: Configurações e presets
- **JSON Export/Import**: Backup externo

## 🎯 Integração com TikFinity

### URLs dos Widgets TikFinity
Para usar, obtenha as URLs dos widgets em:
- **Site oficial**: https://tikfinity.zerody.one/
- **Overlays OBS**: https://tikfinity.zerody.one/tiktok/obsoverlays
- **Gift Overlays**: https://tikfinity.zerody.one/tiktok/giftoverlays
- **API Docs**: https://tikfinity.zerody.one/tiktok/dapi

### Widgets Disponíveis no TikFinity
- Contador de Likes em tempo real
- Alertas de novos seguidores
- Contador de gifts recebidos
- Overlay de chat
- Top doadores
- Barras de progresso para metas
- Text-to-Speech do chat

## 🎨 Dicas de Uso

### Performance
- Mantenha número razoável de widgets (recomendado: até 10)
- Use opacidade baixa para widgets de background
- Ajuste zoom para economizar espaço na tela

### Organização
- Use z-index para sobrepor widgets estrategicamente
- Nomeie seus presets de forma descritiva
- Exporte backups regularmente

### Transmissão
- Teste a configuração antes de ir ao vivo
- Use Ctrl+H para modo limpo durante transmissão
- Trave widgets antes de começar (Ctrl+L)

## 📝 Changelog

### v1.2 (19/11/2025)
- ✅ **Seletor de resoluções predefinidas (720p, 1080p, 1440p, 4K)**
- ✅ **Guias visuais de resolução com cores diferentes (720p azul, 4K rosa)**
- ✅ **Fundo cinza no editor para melhor contraste**
- ✅ **Sistema de zoom de canvas (25% a 200%)**
- ✅ **Copyright com link para @badwise no TikTok**

### v1.1 (19/11/2025)
- ✅ **Links externos sem menus de controle (view.html)**
- ✅ **3 modos de compartilhamento: Preset, Config codificada, Auto-save**
- ✅ **Gerador de links integrado no editor**

### v1.0 (19/11/2025)
- ✅ Sistema de múltiplos iframes configuráveis
- ✅ Controles de transparência, zoom e rotação
- ✅ Posicionamento e tamanho precisos
- ✅ Sistema de camadas (z-index)
- ✅ Bordas customizáveis
- ✅ Salvamento de presets
- ✅ Exportação/Importação JSON
- ✅ Templates TikFinity predefinidos
- ✅ Atalhos de teclado
- ✅ Auto-salvamento com restauração automática
- ✅ **Drag-and-drop profissional**
- ✅ **Resize estilo Photoshop com 8 handles**
- ✅ **Modo interativo para cliques em iframes**
- ✅ Interface em português brasileiro

## 🔮 Próximas Funcionalidades
- [ ] Efeitos visuais (sombras, brilho, filtros CSS)
- [ ] Animações de entrada/saída
- [ ] Hotkeys customizáveis
- [ ] Modo de grid para alinhamento
- [ ] Histórico de configurações (undo/redo)

## 💡 Suporte
Para problemas com widgets do TikFinity, consulte a documentação oficial em:
https://tikfinity.zerody.one/

---

**Desenvolvido por Felipe Fernandes de Araujo ([@badwise](https://www.tiktok.com/@badwise)) para streamers do TikTok LIVE** 🎥✨
